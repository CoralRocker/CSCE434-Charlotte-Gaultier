package ast;

import coco.Token;

import java.util.ArrayList;

public class UnresolvedFunctionVisitor implements NodeVisitor {

    private ArrayList<Token> unresolvedTokens;

    public ArrayList<Token> errors() {
        return unresolvedTokens;
    }

    public UnresolvedFunctionVisitor() {
        unresolvedTokens = new ArrayList<Token>();
    }

    @Override
    public void visit(Addition add) {
        
        add.getLvalue().accept(this);
        add.getRvalue().accept(this);
        
    }

    @Override
    public void visit(ArgList list) {
        
        for( AST ast : list.getArgs() ) {
            ast.accept(this);
        }
        
    }

    @Override
    public void visit(ArrayIndex idx) {
        
        idx.getArray().accept(this);
        idx.getIndex().accept(this);
        
    }

    @Override
    public void visit(Assignment asn) {
        
        asn.getTarget().accept(this);
        asn.getRvalue().accept(this);
        
    }

    @Override
    public void visit(BoolLiteral bool) {}

    @Override
    public void visit(DeclarationList list) {
        
        for( AST decl : list.getContained() ) {
            decl.accept(this);
        }
        

    }

    @Override
    public void visit(Designator des) {
    }

    @Override
    public void visit(Division div) {
        
        div.getLvalue().accept(this);
        div.getRvalue().accept(this);
        
    }

    @Override
    public void visit(FloatLiteral flt) {
    }

    @Override
    public void visit(FuncBody fb) {
        
        if( fb.getVarList() != null )
            fb.getVarList().accept(this);
        fb.getSeq().accept(this);
        
    }

    @Override
    public void visit(FuncCall fc) {
        if( !fc.func.hasType() ) {
            unresolvedTokens.add(fc.funcTok);
        }

        
        fc.getArgs().accept(this);
        
    }

    @Override
    public void visit(FuncDecl fd) {
        
        fd.getBody().accept(this);
        
    }

    @Override
    public void visit(IfStat is) {
        
        is.getIfrel().accept(this);
        is.getIfseq().accept(this);
        if( is.getElseseq() != null ) {
            is.getElseseq().accept(this);
        }
        
    }

    @Override
    public void visit(IntegerLiteral il) {
    }

    @Override
    public void visit(LogicalAnd la) {
        
        la.getLvalue().accept(this);
        la.getRvalue().accept(this);
        
    }

    @Override
    public void visit(LogicalNot ln) {
        
        ln.getRvalue().accept(this);
        
    }

    @Override
    public void visit(LogicalOr lo) {
        
        lo.getLvalue().accept(this);
        lo.getRvalue().accept(this);
        
    }

    @Override
    public void visit(Modulo mod) {
        
        mod.getLvalue().accept(this);
        mod.getRvalue().accept(this);
        
    }

    @Override
    public void visit(Multiplication mul) {
        
        mul.getLvalue().accept(this);
        mul.getRvalue().accept(this);
        
    }

    @Override
    public void visit(Power pwr) {
        
        pwr.getLvalue().accept(this);
        pwr.getRvalue().accept(this);
        

    }

    @Override
    public void visit(Relation rel) {
        
        rel.getLvalue().accept(this);
        rel.getRvalue().accept(this);
        

    }


    @Override
    public void visit(RepeatStat rep) {
        
        rep.getRelation().accept(this);
        rep.getSeq().accept(this);
        
    }

    @Override
    public void visit(Return ret) {
        if( ret.getReturn() != null ) {
            
            ret.getReturn().accept(this);
            
        }
    }

    @Override
    public void visit(RootAST root) {
        
        if( root.getVars() != null )
            root.getVars().accept(this);
        if( root.getFuncs() != null )
            root.getFuncs().accept(this);
        root.getSeq().accept(this);
        
    }

    @Override
    public void visit(StatSeq seq) {
        
        for( AST ast : seq.getSequence() ) {
            ast.accept(this);
        }
        
    }

    @Override
    public void visit(Subtraction sub) {
        
        sub.getLvalue().accept(this);
        sub.getRvalue().accept(this);
        

    }

    @Override
    public void visit(VariableDeclaration var) {
    }

    @Override
    public void visit(WhileStat wstat) {
        
        wstat.getRelation().accept(this);
        wstat.getSeq().accept(this);
        
    }
}
