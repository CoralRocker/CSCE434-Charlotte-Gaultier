package types;

public class IntType extends Type {
    @Override
    public String toString(){
        return "int";
    }

}