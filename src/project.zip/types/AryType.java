package types;

public class AryType extends Type {

}