package types;

public class BoolType extends Type {
    @Override
    public String toString(){
        return "bool";
    }

}