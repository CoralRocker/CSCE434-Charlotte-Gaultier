package types;

public class VoidType extends Type {


}