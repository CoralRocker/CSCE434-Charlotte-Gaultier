package types;

public class FloatType extends Type {
    @Override
    public String toString(){
        return "float";
    }

}