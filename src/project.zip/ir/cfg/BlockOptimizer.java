package ir.cfg;

public class BlockOptimizer extends CFGVisitor {
    @Override
    public Object visit(BasicBlock blk) {
        return null;
    }
}
