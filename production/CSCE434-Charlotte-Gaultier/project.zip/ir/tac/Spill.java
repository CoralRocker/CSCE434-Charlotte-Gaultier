package ir.tac;

public class Spill {
    public final int spillNo;

    public Spill(int spilloc) {
       spillNo = spilloc;
    }

}
